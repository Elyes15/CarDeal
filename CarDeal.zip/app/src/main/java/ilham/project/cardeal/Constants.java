package ilham.project.cardeal;

public class Constants {


    //product categories
    public static final String[] productCategories = {
            "Toyota",
            "Honda",
            "Suzuki",
            "Bmw",
            "Mercedes",
            "Others"
    };

    public static final String[] productCategories1 = {
            "All",
            "Toyota",
            "Honda",
            "Suzuki",
            "Bmw",
            "Mercedes",
            "Others"
    };

}
