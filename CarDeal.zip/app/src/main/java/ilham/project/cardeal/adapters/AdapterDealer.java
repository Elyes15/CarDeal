package ilham.project.cardeal.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import ilham.project.cardeal.R;
import ilham.project.cardeal.models.ModelDealer;

public class AdapterDealer extends RecyclerView.Adapter<AdapterDealer.HolderDealer>{

    private Context context;
    public ArrayList<ModelDealer> dealerList;

    public AdapterDealer(Context context, ArrayList<ModelDealer> dealerList) {
        this.context = context;
        this.dealerList = dealerList;
    }

    @NonNull
    @Override
    public HolderDealer onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //inflate layout row_dealer.xml
        View view = LayoutInflater.from(context).inflate(R.layout.row_dealer, parent, false);
        return new HolderDealer(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderDealer holder, int position) {
        //get data
        ModelDealer modelDealer = dealerList.get(position);
        String accountType = modelDealer.getAccountType();
        String address = modelDealer.getAddress();
        String city = modelDealer.getCity();
        String country = modelDealer.getCountry();
        String deliveryFee = modelDealer.getDeliveryFee();
        String email = modelDealer.getEmail();
        String latitude = modelDealer.getLatitude();
        String longitude = modelDealer.getLongitude();
        String online = modelDealer.getOnline();
        String name = modelDealer.getName();
        String phone = modelDealer.getPhone();
        String uid = modelDealer.getUid();
        String timestamp = modelDealer.getTimestamp();
        String shopOpen = modelDealer.getShopOpen();
        String state = modelDealer.getState();
        String profileImage = modelDealer.getProfileImage();
        String shopName = modelDealer.getShopName();

        //set data
        holder.dealerNameTv.setText(shopName);
        holder.phoneTv.setText(phone);
        holder.addressTv.setText(address);
        //check if online
        if (online.equals("true")){
            //dealer owner is online
            holder.onlineIv.setVisibility(View.VISIBLE);
        }
        else {
            //dealer owner is offline
            holder.onlineIv.setVisibility(View.GONE);
        }
        //check if dealer open
        if (shopName.equals("true")){
            //dealer open
            holder.dealerClosedTv.setVisibility(View.GONE);
        }else {
            //dealer closed
            holder.dealerClosedTv.setVisibility(View.VISIBLE);
        }

        try {
            Picasso.get().load(profileImage).placeholder(R.drawable.ic_store_gray).into(holder.dealerIv);
        }
        catch (Exception e){
            holder.dealerIv.setImageResource(R.drawable.ic_store_gray);
        }

    }

    @Override
    public int getItemCount() {
        return dealerList.size();
    }


    //view holder
    class HolderDealer extends RecyclerView.ViewHolder{

        //ui views of row_dealer.xml
        private ImageView dealerIv, onlineIv;
        private TextView dealerClosedTv, dealerNameTv, phoneTv, addressTv;
        private RatingBar ratingBar;

        public HolderDealer(@NonNull View itemView) {
            super(itemView);

            //init uid views
            dealerIv = itemView.findViewById(R.id.dealerIv);
            onlineIv = itemView.findViewById(R.id.onlineIv);
            dealerClosedTv = itemView.findViewById(R.id.dealerClosedTv);
            dealerNameTv = itemView.findViewById(R.id.dealerNameTv);
            phoneTv = itemView.findViewById(R.id.phoneTv);
            addressTv = itemView.findViewById(R.id.addressTv);
            ratingBar = itemView.findViewById(R.id.ratingBar);
        }
    }
}
